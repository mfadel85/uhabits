import json
import boto3
from datetime import datetime

def lambda_handler(event, context):
    """
    Absolute minimal API - just return test data to verify it works
    """
    
    # Simple CORS headers
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,x-api-key',
        'Access-Control-Allow-Methods': 'GET,OPTIONS'
    }
    
    # Handle preflight
    if event.get('httpMethod') == 'OPTIONS':
        return {'statusCode': 200, 'headers': headers, 'body': ''}
    
    # Return mock data that matches expected format
    mock_data = {
        'group_performance': {
            'Religious': {
                'habit_count': 8,
                'simple_average': 0.75,
                'weighted_average': 0.75,
                'grade': 'B',
                'status': '🕌',
                'icon': '🕌',
                'habits': [
                    {'name': 'Morning Prayer', 'success_rate': 0.8, 'priority': 'HIGH'},
                    {'name': 'Evening Prayer', 'success_rate': 0.7, 'priority': 'HIGH'}
                ]
            },
            'Career & Work': {
                'habit_count': 5,
                'simple_average': 0.85,
                'weighted_average': 0.85,
                'grade': 'A',
                'status': '💼',
                'icon': '💼',
                'habits': [
                    {'name': 'Daily Planning', 'success_rate': 0.9, 'priority': 'HIGH'},
                    {'name': 'Skill Development', 'success_rate': 0.8, 'priority': 'NORMAL'}
                ]
            },
            'Social & Family': {
                'habit_count': 6,
                'simple_average': 0.68,
                'weighted_average': 0.68,
                'grade': 'C',
                'status': '👨‍👩‍👧‍👦',
                'icon': '👨‍👩‍👧‍👦',
                'habits': [
                    {'name': 'Family Time', 'success_rate': 0.7, 'priority': 'HIGH'},
                    {'name': 'Call Friends', 'success_rate': 0.65, 'priority': 'NORMAL'}
                ]
            },
            'Personal Improvement': {
                'habit_count': 6,
                'simple_average': 0.72,
                'weighted_average': 0.72,
                'grade': 'B',
                'status': '🌟',
                'icon': '🌟',
                'habits': [
                    {'name': 'Reading', 'success_rate': 0.8, 'priority': 'NORMAL'},
                    {'name': 'Exercise', 'success_rate': 0.65, 'priority': 'HIGH'}
                ]
            }
        },
        'summary': {
            'total_groups': 4,
            'total_habits_analyzed': 25,
            'data_source': 'Mock Data (Testing)',
            'habits_found': 25
        },
        'last_updated': datetime.now().isoformat(),
        'message': 'API is working with mock data'
    }
    
    return {
        'statusCode': 200,
        'headers': headers,
        'body': json.dumps(mock_data)
    }
